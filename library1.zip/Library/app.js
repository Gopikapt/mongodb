const exp=require("express");
const chalk=require("chalk");
const path=require("path");
const nav=[
    {link:'/books',title:'BOOKS'},
    {link:'/authors',title:'AUTHORS'},
    {link:'/about',title:'ABOUT US'},
    {link:'/contacts',title:'CONTACT US'},
    {link:'/admin',title:'ADD BOOK'},
    {link:'/author',title:'ADD AUTHOR'}
]
    


var app=new exp();

app.use(exp.static(path.join(__dirname,"/public")));
// app.get('/',function(req,res){
//     //res.send("hello from library app");
//     //res.sendFile(__dirname+"/views/index.html");
//     res.sendFile(path.join(__dirname,"/views/index.html"));
// });

app.set('views','./src/views');
app.set('view engine','ejs');
// app.get('/',function(req,res){
//     res.render('index');
// });
const booksRouter=require('./src/routes/bookRoutes')(nav);
app.use('/books',booksRouter);

app.get('/',function(req,res){
    res.render('index',{
            title:"Library",
            //list:['book1','book2','book3']
            nav
    });
});

const authorRouter=require('./src/routes/authorRoutes')(nav);
app.use('/authors',authorRouter);

const aboutRouter=require('./src/routes/aboutRoutes')(nav);
app.use('/about',aboutRouter);

const contactRouter=require('./src/routes/contactRoutes')(nav);
app.use('/contacts',contactRouter);

//const addRouter=require('./src/routes/addRoutes')(nav);
//app.use('/add',addRouter);

const adminRouter=require('./src/routes/adminRoutes')(nav);
app.use('/admin',adminRouter);

const add_author_router=require('./src/routes/add_author_routes')(nav);
app.use('/author',add_author_router);

app.listen(3000,function(){
    console.log("listening to port"+chalk.blue(3000))
});