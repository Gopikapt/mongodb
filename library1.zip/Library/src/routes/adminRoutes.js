const exp=require("express");
const adminRouter=exp.Router();
const BData=require('../model/bookData');

function router(nav)
{
    adminRouter.route('/')
    .get((req,res)=>{
        res.render('add',{nav,title:"Add Book"})
    })
    adminRouter.route('/add')
    .get((req,res)=>
{
    var item={
        name:req.param('name'),
        price:req.param('price'),
        author:req.param('author')
    }
    var book=new BData(item);
    book.save();
    res.redirect('/books');
})
    return adminRouter
}
module.exports=router;