const exp=require("express");
const aboutRouter=exp.Router();

var description = { desc:"dghgjyuygvn"};
function router(nav)
{
    aboutRouter.route('/')
    .get((req,res)=>{
        res.render('about',{nav,title:"About",description})
    })

    return aboutRouter
}
module.exports=router;