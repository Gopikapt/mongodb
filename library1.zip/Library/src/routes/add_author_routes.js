const exp=require("express");
const add_author_router=exp.Router();
const AData=require('../model/authorData');

function router(nav)
{
    add_author_router.route('/')
    .get((req,res)=>{
        res.render('author',{nav,title:"Add Author"})
    })
    add_author_router.route('/add')
    .get((req,res)=>{
        var item={name:req.param('name'),
        place:req.param('place'),
        books_published:req.param('books_published')}

    var author=new AData(item)
    author.save();
    res.redirect('/authors')
    })
    return add_author_router
}
module.exports=router;