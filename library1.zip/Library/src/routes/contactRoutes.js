const exp=require("express");
const contactRouter=exp.Router();

var description={book:"HELLO"};

function router(nav)
{
    contactRouter.route('/')
    .get((req,res)=>{
        res.render('contact',{nav,title:"Contact",description})
    })
    return contactRouter
}
module.exports=router;