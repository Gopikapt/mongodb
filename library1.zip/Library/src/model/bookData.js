const mongoose=require("mongoose");
mongoose.connect('mongodb://localhost:27017/libraryappformongoose');
const Schema=mongoose.Schema;

var NewBookSchema=new Schema({
    name:String,
    price:Number,
    author:String
});

var Bookdata=mongoose.model('Book-Data',NewBookSchema);
module.exports=Bookdata;