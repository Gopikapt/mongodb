const exp=require("express");
const authorRouter=exp.Router();
const AuthorData=require('../model/authorData')

function router(nav)
{
//var authors=[
  //  {author:'ghi',name:'abcd'},
    //{author:'zxc',name:'efgh'},
    //{author:'bnm',name:'ijkl'},
    //{author:'mnb',name:'mnop'},
    //{author:'oiu',name:'qrst'}
//];
authorRouter.route('/')
.get((req,res)=>{
    //res.send("hello author");
    AuthorData.find()
    .then(function(authors){
    res.render('authors',{title:"Library",authors,nav});
    });
   
});
//AuthorRouter.route('/single')
//.get((req,res)=>{
   // res.send("hello single author");
//});
authorRouter.route('/:id')               
.get((req,res)=>{
const id=req.params.id;
AuthorData.findOne({_id:id})
.then(function(author){
res.render('author',{
    title:"Library",
    nav,
   author});
});
});
return authorRouter
}
module.exports=router;