const exp=require("express");
const booksRouter=exp.Router();
const BookData=require('../model/bookData')
function router(nav)
{
//var books=[
    //{title :'book1',genre:'def',author:'ghi'},
    //{title :'book2',genre:'asd',author:'zxc'},
    //{title :'book3',genre:'hjk',author:'bnm'},
    //{title :'book4',genre:'lkj',author:'mnb'},
    //{title :'book5',genre:'ghj',author:'oiu'}
//];
booksRouter.route('/')
.get((req,res)=>{
   // res.send("hello books");
   BookData.find()
   .then(function(books){
       res.render('books',{nav,title:"Library",books});
   });

   //res.render('books' ,{
    //title:"Book Details",
    //nav,
      // books
//})

});
booksRouter.route('/:id')      //variable id           
.get((req,res)=>{
    //res.send("hello single book");
const id=req.params.id; //const id is any variable
    BookData.findOne({_id:id})
    .then(function(book){
    res.render(
        'book',{
            title:"Library",
            nav,
           book
            });
        });
});
return booksRouter
}
module.exports=router;