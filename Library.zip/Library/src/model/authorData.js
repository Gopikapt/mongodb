const mongoose=require("mongoose");
mongoose.connect('mongodb://localhost:27017/libraryappformongoose');
const Schema=mongoose.Schema;

var NewAuthorSchema=new Schema({
    name:String,
    place:String,
    books_published:Number
});

var AuthorData=mongoose.model('Author-Data',NewAuthorSchema);
module.exports=AuthorData;